#coding=utf-8
import numpy as np
import xgboost as xgb
'''
python mapfeat.py
python mknfold.py machine.txt 1
'''
param = {}

param['booster'] = 'gbtree'
param['objective'] = 'reg:linear'
param['eta'] = 1.0 
param['gamma'] = 1.0 
param['min_child_weight'] = 1 
param['max_depth'] = 3 

num_round = 2
save_period = 0 
dtrain = xgb.DMatrix('machine.txt.train')
dtest = xgb.DMatrix('machine.txt.test')
watchlist  = [(dtest,'eval'), (dtrain,'train')]

bst = xgb.train(param, dtrain, num_round, watchlist)
preds = bst.predict(dtest)
# save model
#bst.save_model('outInfo/0001.model')
# dump model
#bst.dump_model('outInfo/dump.raw.txt')