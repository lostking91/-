#coding=utf-8
# ��������	��������Lost
'''
# ��������
from numpy import *
import operator
from os import listdir
import random
import linecache
from ReadFile import *
trainMat,testMat=file2mat('dermatology.txt',0.8)
savemat('dermatology.txt.train',trainMat)
savemat('dermatology.txt.test',testMat)
'''
from ReadFile import *
import numpy as np
import xgboost as xgb
xgtrain = readmat('dermatology.txt.train')
xgtest = readmat('dermatology.txt.test')
train_Y=xgtrain[:,34]-1
test_Y=xgtest[:,34]-1
xg_train = xgb.DMatrix( xgtrain[:,:33], label=train_Y)
xg_test= xgb.DMatrix(xgtest[:,:33], label=test_Y)

# setup parameters for xgboost
param = {}
# use softmax multi-class classification
param['objective'] = 'multi:softmax'
# scale weight of positive examples
param['eta'] = 0.1
param['max_depth'] = 6
param['silent'] = 1
param['num_class'] = 6

watchlist = [ (xg_train,'train'), (xg_test, 'test') ]
num_round = 5
bst = xgb.train(param, xg_train, num_round, watchlist );
# get prediction
pred = bst.predict( xg_test );

print ('predicting, classification error=%f' % (sum( int(pred[i]) != test_Y[i] for i in range(len(test_Y))) / float(len(test_Y)) ))

# do the same thing again, but output probabilities
param['objective'] = 'multi:softprob'
bst = xgb.train(param, xg_train, num_round, watchlist );
# Note: this convention has been changed since xgboost-unity
# get prediction, this is in 1D array, need reshape to (ndata, nclass)
yprob = bst.predict( xg_test ).reshape( test_Y.shape[0], 6 )
ylabel = np.argmax(yprob, axis=1)

print ('predicting, classification error=%f' % (sum( int(ylabel[i]) != test_Y[i] for i in range(len(test_Y))) / float(len(test_Y)) ))
