original	the original official xgboost tutorial in python, but it use shell in linux, so I change it in windows. And I analysis the function of xgboost.  
	mapfeat.py -> can know how to change a file with alphabet to a libsvm data. And I learn the code in 201649test.
	mknfold.py -> random data in train and test.
	README.md and mushroom.conf -> learning it and create code in windows. And I code in 2016411test.