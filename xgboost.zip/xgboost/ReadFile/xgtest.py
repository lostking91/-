#coding=utf-8
# ��������	��������Lost
'''
Read File on 2016.4.4
data mining using xgboost


PengKun
'''
from numpy import np
import xgboost as xgb
print "���سɹ�"
# ��ȡ�ļ�
def readmat(datafile,labelfile):
	data=np.loadtxt(datafile)
	label=np.loadtxt(labelfile)
	redata=xgb.DMatrix(data,label=label)
	return redata

# ����
trainmf='D:\\lostfield\\python\\xgboost\\testData\\trainmat.txt'
trainlf='D:\\lostfield\\python\\xgboost\\testData\\trainlabel.txt'
testmf='D:\\lostfield\\python\\xgboost\\testData\\testmat.txt'
testlf='D:\\lostfield\\python\\xgboost\\testData\\testlabel.txt'
traind=readmat(trainmf,trainlf)
testd=readmat(testmf,testlf)