#coding=utf-8
# 我是中文	————Lost
from numpy import *
import operator
from os import listdir
import linecache
print "加载成功"
c=arange(12).reshape(3,4)
randpart=0.7
randNumber=[i for i in range(3)]
random.shuffle(randNumber)
partition=int(randpart*3) #2
trainLabel=[]
testLabel=[]	
trainPart=randNumber[:partition-1]	# 2
testPart=randNumber[partition-1:]   # 1
testMat= zeros((len(testPart),3))  # 2
trainMat=zeros((len(trainPart),3))   # 1
for i,x in enumerate(trainPart):
	trainMat[i,:]=c[x, :-1]
	trainLabel.append(int(c[x, -1]))
for j,y in enumerate(testPart):
	testMat[j,:]=c[y, :-1]
	testLabel.append(int(c[y, -1]))
print trainMat,trainLabel,testMat,testLabel
