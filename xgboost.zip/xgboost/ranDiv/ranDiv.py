#coding=utf-8
# ��������	��������Lost
'''
Rand divid data and Read File on 2016.4.16
Based on .\\xgboost\\demo\\binary_classification\\mknfold.py
ranDivFile(): read file, save train file and test file.
ranDivMat(): read data, save train data and test data.
randpart>=2

PengKun
'''
from numpy import *
import operator
import random
print "���سɹ�"

def ranDivFile(dataFile,randpart):
	random.seed( 10 )
	if randpart<=1:
		print "wrong randpart!"
	else:
		fi = open( dataFile, 'r' )
		ftr = open( dataFile + '.train', 'w' )
		fte = open( dataFile + '.test', 'w' )	
		for l in fi:
			if random.randint( 1 , randpart ) == 1:
				fte.write( l )
			else:
				ftr.write( l )
		fi.close()
		ftr.close()
		fte.close()

def ranDivMat(data,randpart):
	random.seed( 10 )
	if randpart<=1:
		print "wrong randpart!"
	else:
		m,n=data.shape
		ftr = open( data + '.train', 'w' )
		fte = open( data + '.test', 'w' )
		testMat= zeros((len(m/randpart),n))
		trainMat=zeros((len(m-m/randpart),n))
		trainn=0
		testn=0
		for i in range(m):
			if random.randint( 1 , randpart ) == 1:
				fte.write( data[i,] )
				testMat[testn,]=alldata[i, ]
				testn=testn+1
			else:
				ftr.write( data[i,] )
				trainMat[i,]=alldata[i, ]
				trainn=tainn+1
		ftr.close()
		fte.close()
		return trainMat,testMat
